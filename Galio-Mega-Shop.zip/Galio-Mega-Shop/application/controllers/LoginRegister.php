<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginRegister extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->validation_msg = array();
		$this->load->model('LoginRegister_model');
	}

	public function index()
	{
		$this->load->view('header/header');
		$this->load->view('loginregister/middle');
		$this->load->view('footer/footer');
	}
	public function validate_name($str) {

		if($str==''){
			$this->form_validation->set_message("validate_name", '%s is required.');
            return false;
		} else if (preg_match("/^([-a-z_ ])+$/i", $str) !== 0) {
            return true;
        } else {
            $this->form_validation->set_message("validate_name", '%s is not valid.');
            return false;
        }
	}
	public function prepare_validation_arr(){
		$res = '';
		if ($this->form_validation->run() == FALSE)
	    {
	    	$res = explode('*',validation_errors());
	    	//echo "<pre>";print_r($this->validation_msg);
	    	if(!in_array($res[count($res)-2], $this->validation_msg)){
	    		
	    		array_push($this->validation_msg,$res[count($res)-2]);
	    		$res = $res[count($res)-2];
	    	} else {
	    		$res = '';
	    	}
		}
		return $res;

	}
	public function registeruser()
	{
		//echo "<pre>";print_r($_POST);exit;
		$this->form_validation->set_error_delimiters('', '*');
	    $this->form_validation->set_rules('fullname', 'Name', 'trim|required|callback_validate_name');

	    $data['message']['fullname'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
	    $data['message']['email'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('password', 'Password', 'required');
	    $data['message']['password'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required');
	    $data['message']['cpassword'] = $this->prepare_validation_arr();

	    if ($this->form_validation->run() == FALSE) {
	    	
	        $data['status'] = 0;
	    } else {

	    	if($_POST['password']!=$_POST['cpassword']){
	    		$data['status'] = 0;
		    	$data['message']['password'] 	= 'Should be match with confirm password.';
		    	$data['message']['cpassword'] 	= 'Should be match with password.';
		    } else {
		    	$data['status'] = 1;
		       	$a = $this->LoginRegister_model->insert($_REQUEST);
		       	if($a==1){
		       		$data['status'] = 0;
		       		$data['message']['email'] = 'Dublicate email id.';
		       	} else if($a==2){
		       		$data['status'] = 0;
		       		$data['message']['contact'] = 'Dublicate mobile number.';
		       	} else {
		       		$data['status'] = 1;
		       		$data['message'] = $a;
		       	}
		    }
	    }

	    unset($this->validation_msg);
	    echo json_encode($data);
	}

	public function loginuser()
	{
		//echo "<pre>";print_r($_POST);exit;
		$this->form_validation->set_error_delimiters('', '*');
	   
	    $this->form_validation->set_rules('loginemail', 'Email', 'trim|required|valid_email');
	    $data['message']['loginemail'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('loginpassword', 'Password', 'required');
	    $data['message']['loginpassword'] = $this->prepare_validation_arr();

	    if ($this->form_validation->run() == FALSE) {
	    	
	        $data['status'] = 0;
	    } else {

	    	$data['status'] = 1;
	       	$res = $this->LoginRegister_model->loginchk($_REQUEST['loginemail'],'','email');
	       	if(count($res)>0){

	       		$res1 = $this->LoginRegister_model->loginchk($_REQUEST['loginemail'],$_REQUEST['loginpassword'],'password');

	       		if(count($res1)>0){
	       			$_SESSION['user_id']=$res1[0]['id'];
	       			$data['status'] = 1;
		       		$data['message'] = 'Login successfully';
	       		} else {
	       			$data['status'] = 0;
	       			$data['message']['loginpassword'] = 'Invalid password.';
	       		}	
	       	} else {
	       		$data['status'] = 0;
	       		$data['message']['loginemail'] = 'Invalid email id.';
	       	}
	    }

	    unset($this->validation_msg);
	    echo json_encode($data);
	}

	public function logout()
	{
		unset($_SESSION['user_id']);
		redirect('/');
	}
}
