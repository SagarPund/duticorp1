<!-- color switcher start -->
    <div class="color-switcher">
        <div class="color-switcher-inner">
            <div class="switcher-icon">
                <i class="fa fa-cog fa-spin"></i>
            </div>

            <div class="switcher-panel-item">
                <h3>Color Schemes</h3>
                <ul class="nav flex-wrap colors">
                    <li class="default active" data-color="default" data-toggle="tooltip" data-placement="top" title="Red"></li>
                    <li class="green" data-color="green" data-toggle="tooltip" data-placement="top" title="Green"></li>
                    <li class="soft-green" data-color="soft-green" data-toggle="tooltip" data-placement="top" title="Soft-Green"></li>
                    <li class="sky-blue" data-color="sky-blue" data-toggle="tooltip" data-placement="top" title="Sky-Blue"></li>
                    <li class="orange" data-color="orange" data-toggle="tooltip" data-placement="top" title="Orange"></li>
                    <li class="violet" data-color="violet" data-toggle="tooltip" data-placement="top" title="Violet"></li>
                </ul>
            </div>

            <div class="switcher-panel-item">
                <h3>Layout Style</h3>
                <ul class="nav layout-changer">
                    <li><button class="btn-layout-changer active" data-layout="wide">Wide</button></li>
                    <li><button class="btn-layout-changer" data-layout="boxed">Boxed</button></li>
                </ul>
            </div>

            <div class="switcher-panel-item bg">
                <h3>Background Pattern</h3>
                <ul class="nav flex-wrap bgbody-style bg-pattern">
                    <li><img src="assets/img/bg-panel/bg-pettern/1.png" alt="Pettern"></li>
                    <li><img src="assets/img/bg-panel/bg-pettern/2.png" alt="Pettern"></li>
                    <li><img src="assets/img/bg-panel/bg-pettern/3.png" alt="Pettern"></li>
                    <li><img src="assets/img/bg-panel/bg-pettern/4.png" alt="Pettern"></li>
                    <li><img src="assets/img/bg-panel/bg-pettern/5.png" alt="Pettern"></li>
                    <li><img src="assets/img/bg-panel/bg-pettern/6.png" alt="Pettern"></li>
                </ul>
            </div>

            <div class="switcher-panel-item bg">
                <h3>Background Image</h3>
                <ul class="nav flex-wrap bgbody-style bg-img">
                    <li><img src="assets/img/bg-panel/bg-img/01.jpg" alt="Images"></li>
                    <li><img src="assets/img/bg-panel/bg-img/02.jpg" alt="Images"></li>
                    <li><img src="assets/img/bg-panel/bg-img/03.jpg" alt="Images"></li>
                    <li><img src="assets/img/bg-panel/bg-img/04.jpg" alt="Images"></li>
                    <li><img src="assets/img/bg-panel/bg-img/05.jpg" alt="Images"></li>
                    <li><img src="assets/img/bg-panel/bg-img/06.jpg" alt="Images"></li>
                </ul>
            </div>
        </div>
    </div>
    <!-- color switcher end -->

    <div class="wrapper box-layout">

        <?php $this->view('header/head-common.php'); ?>

        <!-- breadcrumb area start -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="breadcrumb-wrap">
                            <nav aria-label="breadcrumb">
                                <ul class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                    <li class="breadcrumb-item"><a href="shop-grid-left-sidebar.html">shop</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">checkout</li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb area end -->

        <!-- checkout main wrapper start -->
        <div class="checkout-page-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- Checkout Login Coupon Accordion Start -->
                        <div class="checkoutaccordion" id="checkOutAccordion">
                            <?php if($this->session->userdata('user_id') ==''){ ?>
                            <div class="card">
                                <h3>Returning Customer? <span data-toggle="collapse" data-target="#logInaccordion">Click Here To Login</span></h3>
        
                                <div id="logInaccordion" class="collapse" data-parent="#checkOutAccordion">
                                    <div class="card-body">
                                        <p>If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing &amp; Shipping section.</p>
                                        <div class="login-reg-form-wrap mt-20">
                                            <div class="row">
                                                <div class="col-lg-7 m-auto">
                                                    <form method="post" id="login_form">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="single-input-item">
                                                                    <input type="text" name="loginemail" placeholder="Enter your email"/>
                                                                    <span class="loginemail-error hide validation-error"> Please enter email  </span>
                                                                </div>
                                                            </div>
        
                                                            <div class="col-md-12">
                                                                <div class="single-input-item">
                                                                    <input type="password" name="loginpassword" placeholder="Enter your Password"/>
                                                                    <span class="loginpassword-error hide validation-error"> Please enter password  </span>
                                                                </div>
                                                            </div>
                                                        </div>
        
                                                        <div class="single-input-item">
                                                            <div class="login-reg-form-meta d-flex align-items-center justify-content-between">
                                                                <div class="remember-meta">
                                                                    <div class="custom-control custom-checkbox">
                                                                        <input type="checkbox" class="custom-control-input" id="rememberMe" />
                                                                        <label class="custom-control-label" for="rememberMe">Remember Me</label>
                                                                    </div>
                                                                </div>
        
                                                                <a href="#" class="forget-pwd">Forget Password?</a>
                                                            </div>
                                                        </div>
                                                        <span style="color:green;" id="login_success_msg"></span>
                                                        <div class="single-input-item">
                                                            <button class="check-btn sqr-btn" id="login_submit_btn">Login</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php } ?>
        
                            <div class="card">
                                <h3>Have A Coupon? <span data-toggle="collapse" data-target="#couponaccordion">Click Here To Enter Your Code</span></h3>
                                <div id="couponaccordion" class="collapse" data-parent="#checkOutAccordion">
                                    <div class="card-body">
                                        <div class="cart-update-option">
                                            <div class="apply-coupon-wrapper">
                                                <form action="#" method="post" class=" d-block d-md-flex">
                                                    <input type="text" placeholder="Enter Your Coupon Code" required />
                                                    <button class="check-btn sqr-btn">Apply Coupon</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Checkout Login Coupon Accordion End -->
                    </div>
                </div>
        
                <div class="row">
                    <!-- Checkout Billing Details -->
                    <div class="col-lg-6">
                        <div class="checkout-billing-details-wrap">
                            <h2>Billing Details</h2>
                            <div class="billing-form-wrap">
                                <form method="post" id="checkout_form">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label for="f_name" class="required">First Name</label>
                                                <input type="text" name="billing_fname" id="billing_fname" placeholder="First Name" />
                                                <span class="billing_fname-error hide validation-error"> Please enter email  </span>
                                            </div>
                                        </div>
        
                                        <div class="col-md-6">
                                            <div class="single-input-item">
                                                <label for="l_name" class="required">Last Name</label>
                                                <input type="text" name="billing_lname" id="billing_lname" placeholder="Last Name" />
                                                <span class="billing_lname-error hide validation-error"> Please enter email  </span>
                                            </div>
                                        </div>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="email" class="required">Email Address</label>
                                        <input type="text" name="billing_email" id="billing_email" placeholder="Email Address" />
                                        <span class="billing_email-error hide validation-error"> Please enter email  </span>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="com-name">Company Name</label>
                                        <input type="text" name="billing_company_name" id="billing_company_name" placeholder="Company Name" />
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="country" class="required">Country</label>
                                        <select name="billing_country" id="country">
                                            <option value="">Select Country</option>
                                            <option value="Afghanistan">Afghanistan</option>
                                            <option value="Albania">Albania</option>
                                            <option value="Algeria">Algeria</option>
                                            <option value="Armenia">Armenia</option>
                                            <option value="Bangladesh">Bangladesh</option>
                                            <option value="India">India</option>
                                            <option value="Pakistan">Pakistan</option>
                                            <option value="England">England</option>
                                            <option value="London">London</option>
                                            <option value="London">London</option>
                                            <option value="Chaina">China</option>
                                        </select>
                                        <span class="billing_country-error hide validation-error"> Please enter email  </span>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="street-address" class="required pt-20">Street address</label>
                                        <input type="text" name="billing_address_line1" id="billing_address_line1" placeholder="Street address Line 1" />
                                        <span class="billing_address_line1-error hide validation-error"> Please enter email  </span>
                                    </div>
        
                                    <div class="single-input-item">
                                        <input type="text" name="billing_address_line2" id="billing_address_line2" placeholder="Street address Line 2 (Optional)" />
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="town" class="required">Town / City</label>
                                        <input type="text" name="billing_city" id="billing_city"   placeholder="Town / City" />
                                        <span class="billing_city-error hide validation-error"> Please enter email  </span>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="state">State / Divition</label>
                                        <input type="text" name="billing_state" id="billing_state"   placeholder="State / Divition" />
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="postcode" class="required">Postcode / ZIP</label>
                                        <input type="text" name="billing_postcode" id="billing_postcode"   placeholder="Postcode / ZIP" />
                                        <span class="billing_postcode-error hide validation-error"> Please enter email  </span>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="phone">Phone</label>
                                        <input type="text" name="billing_phone" id="billing_phone"   placeholder="Phone" />
                                    </div>
        
                                    <div class="checkout-box-wrap">
                                        <div class="single-input-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" name="create_pwd" id="create_pwd">
                                                <label class="custom-control-label" for="create_pwd">Create an account?</label>
                                            </div>
                                        </div>
                                        <div class="account-create single-form-row">
                                            <p>Create an account by entering the information below. If you are a returning customer please login at the top of the page.</p>
                                            <div class="single-input-item">
                                                <label for="pwd" class="required">Account Password</label>
                                                <input type="password" name="account_password" id="account_password"   placeholder="Account Password" />
                                                <span class="account_password-error hide validation-error"> Please enter email  </span>
                                            </div>
                                        </div>
                                    </div>
        
                                    <div class="checkout-box-wrap">
                                        <div class="single-input-item">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" name="ship_to_different" id="ship_to_different">
                                                <label class="custom-control-label" for="ship_to_different">Ship to a different address?</label>
                                            </div>
                                        </div>
                                        <div class="ship-to-different single-form-row">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="single-input-item">
                                                        <label for="f_name" class="required">First Name</label>
                                                        <input type="text" name="shipping_fname" id="shipping_fname" placeholder="First Name" />
                                                        <span class="shipping_fname-error hide validation-error"> Please enter email  </span>
                                                    </div>
                                                </div>

                                                <div class="col-md-6">
                                                    <div class="single-input-item">
                                                        <label for="l_name" class="required">Last Name</label>
                                                        <input type="text" name="shipping_lname" id="shipping_lname" placeholder="Last Name" />
                                                        <span class="shipping_lname-error hide validation-error"> Please enter email  </span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="single-input-item">
                                                <label for="email" class="required">Email Address</label>
                                                <input type="text" name="shipping_email" id="shipping_email" placeholder="Email Address" />
                                                <span class="shipping_email-error hide validation-error"> Please enter email  </span>
                                            </div>

                                            <div class="single-input-item">
                                                <label for="com-name">Company Name</label>
                                                <input type="text" name="shipping_company_name" id="shipping_company_name" placeholder="Company Name" />
                                            </div>

                                            <div class="single-input-item">
                                                <label for="country" class="required">Country</label>
                                                <select name="shipping_country" id="country">
                                                    <option value="">Select Country</option>
                                                    <option value="Afghanistan">Afghanistan</option>
                                                    <option value="Albania">Albania</option>
                                                    <option value="Algeria">Algeria</option>
                                                    <option value="Armenia">Armenia</option>
                                                    <option value="Bangladesh">Bangladesh</option>
                                                    <option value="India">India</option>
                                                    <option value="Pakistan">Pakistan</option>
                                                    <option value="England">England</option>
                                                    <option value="London">London</option>
                                                    <option value="London">London</option>
                                                    <option value="Chaina">China</option>
                                                </select>
                                                <span class="shipping_country-error hide validation-error"> Please enter email  </span>
                                            </div>

                                            <div class="single-input-item">
                                                <label for="street-address" class="required pt-20">Street address</label>
                                                <input type="text" name="shipping_address_line1" id="shipping_address_line1" placeholder="Street address Line 1" />
                                                <span class="shipping_address_line1-error hide validation-error"> Please enter email  </span>
                                            </div>

                                            <div class="single-input-item">
                                                <input type="text" name="shipping_address_line2" id="shipping_address_line2" placeholder="Street address Line 2 (Optional)" />
                                            </div>

                                            <div class="single-input-item">
                                                <label for="town" class="required">Town / City</label>
                                                <input type="text" name="shipping_city" id="shipping_city"   placeholder="Town / City" />
                                                <span class="shipping_city-error hide validation-error"> Please enter email  </span>
                                            </div>

                                            <div class="single-input-item">
                                                <label for="state">State / Divition</label>
                                                <input type="text" name="shipping_state" id="shipping_state"   placeholder="State / Divition" />
                                            </div>

                                            <div class="single-input-item">
                                                <label for="postcode" class="required">Postcode / ZIP</label>
                                                <input type="text" name="shipping_postcode" id="shipping_postcode"   placeholder="Postcode / ZIP" />
                                                <span class="shipping_postcode-error hide validation-error"> Please enter email  </span>
                                            </div>
                                        </div>
                                    </div>
        
                                    <div class="single-input-item">
                                        <label for="ordernote">Order Note</label>
                                        <textarea name="ordernote" id="ordernote" cols="30" rows="3" placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                                    </div>
                                    <input type="hidden" name="total_amount" id="total_amount" value="1000">
                                </form>
                            </div>
                        </div>
                    </div>
        
                    <!-- Order Summary Details -->
                    <div class="col-lg-6">
                        <div class="order-summary-details mt-md-26 mt-sm-26">
                            <h2>Your Order Summary</h2>
                            <div class="order-summary-content mb-sm-4">
                                <!-- Order Summary Table -->
                                <div class="order-summary-table table-responsive text-center">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Products</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><a href="single-product.html">Suscipit Vestibulum <strong> × 1</strong></a></td>
                                                <td>$165.00</td>
                                            </tr>
                                            <tr>
                                                <td><a href="single-product.html">Ami Vestibulum suscipit <strong> × 4</strong></a></td>
                                                <td>$165.00</td>
                                            </tr>
                                            <tr>
                                                <td><a href="single-product.html">Vestibulum suscipit <strong> × 2</strong></a></td>
                                                <td>$165.00</td>
                                            </tr>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td>Sub Total</td>
                                                <td><strong>$400</strong></td>
                                            </tr>
                                            <tr>
                                                <td>Shipping</td>
                                                <td class="d-flex justify-content-center">
                                                    <ul class="shipping-type">
                                                        <li>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" id="flatrate" name="shipping" class="custom-control-input" checked />
                                                                <label class="custom-control-label" for="flatrate">Flat Rate: $70.00</label>
                                                            </div>
                                                        </li>
                                                        <li>
                                                            <div class="custom-control custom-radio">
                                                                <input type="radio" id="freeshipping" name="shipping" class="custom-control-input" />
                                                                <label class="custom-control-label" for="freeshipping">Free Shipping</label>
                                                            </div>
                                                        </li>
                                                    </ul>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Total Amount</td>
                                                <td><strong>$470</strong></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- Order Payment Method -->
                                <div class="order-payment-method">
                                    <div class="single-payment-method show">
                                        <div class="payment-method-name">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="cashon" name="paymentmethod" value="cash" class="custom-control-input" checked  />
                                                <label class="custom-control-label" for="cashon">Cash On Delivery</label>
                                            </div>
                                        </div>
                                        <div class="payment-method-details" data-method="cash">
                                            <p>Pay with cash upon delivery.</p>
                                        </div>
                                    </div>
                                    <div class="single-payment-method">
                                        <div class="payment-method-name">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="directbank" name="paymentmethod" value="bank" class="custom-control-input" />
                                                <label class="custom-control-label" for="directbank">Direct Bank Transfer</label>
                                            </div>
                                        </div>
                                        <div class="payment-method-details" data-method="bank">
                                            <p>Make your payment directly into our bank account. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account..</p>
                                        </div>
                                    </div>
                                    <div class="single-payment-method">
                                        <div class="payment-method-name">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="checkpayment" name="paymentmethod" value="check" class="custom-control-input" />
                                                <label class="custom-control-label" for="checkpayment">Pay with Check</label>
                                            </div>
                                        </div>
                                        <div class="payment-method-details" data-method="check">
                                            <p>Please send a check to Store Name, Store Street, Store Town, Store State / County, Store Postcode.</p>
                                        </div>
                                    </div>
                                    <div class="single-payment-method">
                                        <div class="payment-method-name">
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="paypalpayment" name="paymentmethod" value="paypal" class="custom-control-input" />
                                                <label class="custom-control-label" for="paypalpayment">Paypal <img src="assets/img/paypal-card.jpg" class="img-fluid paypal-card" alt="Paypal" /></label>
                                            </div>
                                        </div>
                                        <div class="payment-method-details" data-method="paypal">
                                            <p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account.</p>
                                        </div>
                                    </div>
                                    <div class="summary-footer-area">
                                        <div class="custom-control custom-checkbox mb-14">
                                            <input type="checkbox" class="custom-control-input" id="terms" required />
                                            <label class="custom-control-label" for="terms">I have read and agree to the website <a
                                                href="index.html">terms and conditions.</a></label>
                                        </div>
                                        <span id="order_success_msg" style="color:green;" ></span>
                                        <button type="button" class="check-btn sqr-btn" id="place_order">Place Order</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- checkout main wrapper end -->

        <!-- brand area start -->
        <div class="brand-area pt-28 pb-30 pt-md-10 pt-sm-30">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title mb-30">
                            <div class="title-icon">
                                <i class="fa fa-crop"></i>
                            </div>
                            <h3>Popular Brand</h3>
                        </div> <!-- section title end -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="brand-active slick-padding slick-arrow-style">
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br1.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br2.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br3.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br4.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br5.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br6.png" alt=""></a>
                            </div>
                            <div class="brand-item text-center">
                                <a href="#"><img src="assets/img/brand/br4.png" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- brand area end -->