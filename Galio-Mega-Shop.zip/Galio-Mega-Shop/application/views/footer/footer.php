    <!-- footer area start -->
    <footer>
        <!-- footer top start -->
        <div class="footer-top bg-black pt-14 pb-14">
            <div class="container">
                <div class="footer-top-wrapper">
                    <div class="newsletter__wrap">
                        <div class="newsletter__title">
                            <div class="newsletter__icon">
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="newsletter__content">
                                <h3>sign up for newsletter</h3>
                                <p>Duis autem vel eum iriureDuis autem vel eum</p>
                            </div>
                        </div>
                        <div class="newsletter__box">
                            <form id="mc-form">
                                <input type="email" id="mc-email" autocomplete="off" placeholder="Email">
                                <button id="mc-submit">subscribe!</button>
                            </form>
                        </div>
                        <!-- mailchimp-alerts Start -->
                        <div class="mailchimp-alerts">
                            <div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
                            <div class="mailchimp-success"></div><!-- mailchimp-success end -->
                            <div class="mailchimp-error"></div><!-- mailchimp-error end -->
                        </div>
                        <!-- mailchimp-alerts end -->
                    </div>
                    <div class="social-icons">
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a>
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a>
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Google-plus"><i class="fa fa-google-plus"></i></a>
                        <a href="#" data-toggle="tooltip" data-placement="top" title="Youtube"><i class="fa fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer top end -->

        <!-- footer main start -->
        <div class="footer-widget-area pt-40 pb-38 pb-sm-10">
            <div class="container">
                <div class="row">
                    <div class="col-md-3 col-sm-6">
                        <div class="footer-widget mb-sm-30">
                            <div class="widget-title mb-10 mb-sm-6">
                                <h4>contact us</h4>
                            </div>
                            <div class="widget-body">
                                <ul class="location">
                                    <li><i class="fa fa-envelope"></i>support@galio.com</li>
                                    <li><i class="fa fa-phone"></i>(800) 0123 456 789</li>
                                    <li><i class="fa fa-map-marker"></i>Address:  1234 - Bandit Tringi Aliquam Vitae. New York</li>
                                </ul>
                                <a class="map-btn" href="contact-us.html">open in google map</a>
                            </div>
                        </div> <!-- single widget end -->
                    </div> <!-- single widget column end -->
                    <div class="col-md-3 col-sm-6">
                        <div class="footer-widget mb-sm-30">
                            <div class="widget-title mb-10 mb-sm-6">
                                <h4>my account</h4>
                            </div>
                            <div class="widget-body">
                                <ul>
                                    <li><a href="#">my account</a></li>
                                    <li><a href="#">my cart</a></li>
                                    <li><a href="#">checkout</a></li>
                                    <li><a href="#">my wishlist</a></li>
                                    <li><a href="#">login</a></li>
                                </ul>
                            </div>
                        </div> <!-- single widget end -->
                    </div> <!-- single widget column end -->
                    <div class="col-md-3 col-sm-6">
                        <div class="footer-widget mb-sm-30">
                            <div class="widget-title mb-10 mb-sm-6">
                                <h4>short code</h4>
                            </div>
                            <div class="widget-body">
                                <ul>
                                    <li><a href="#">gallery</a></li>
                                    <li><a href="#">accordion</a></li>
                                    <li><a href="#">carousel</a></li>
                                    <li><a href="#">map</a></li>
                                    <li><a href="#">tab</a></li>
                                </ul>
                            </div>
                        </div> <!-- single widget end -->
                    </div> <!-- single widget column end -->
                    <div class="col-md-3 col-sm-6">
                        <div class="footer-widget mb-sm-30">
                            <div class="widget-title mb-10 mb-sm-6">
                                <h4>product tags</h4>
                            </div>
                            <div class="widget-body">
                                <ul>
                                    <li><a href="#">computer</a></li>
                                    <li><a href="#">camera</a></li>
                                    <li><a href="#">smart phone</a></li>
                                    <li><a href="#">watch</a></li>
                                    <li><a href="#">tablet</a></li>
                                </ul>
                            </div>
                        </div> <!-- single widget end -->
                    </div> <!-- single widget column end -->
                </div>
            </div>
        </div>
        <!-- footer main end -->

        <!-- footer bootom start -->
        <div class="footer-bottom-area bg-gray pt-20 pb-20">
            <div class="container">
                <div class="footer-bottom-wrap">
                    <div class="copyright-text">
                        <p><a target="_blank" href="https://www.templateshub.net">Templates Hub</a></p>
                    </div>
                    <div class="payment-method-img">
                        <img src="assets/img/payment.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <!-- footer bootom end -->
    </footer>
    <!-- footer area end -->
</div>

<!-- Scroll to top start -->
<div class="scroll-top not-visible">
    <i class="fa fa-angle-up"></i>
</div>
<!-- Scroll to Top End -->

<script type="text/javascript">
    var basepath = '<?php echo base_url(); ?>';
</script>

<!--All jQuery, Third Party Plugins & Activation (main.js) Files-->
<script src="<?php echo base_url(); ?>assets/js/vendor/modernizr-3.6.0.min.js"></script>
<!-- Jquery Min Js -->
<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-3.3.1.min.js"></script>
<!-- Popper Min Js -->
<script src="<?php echo base_url(); ?>assets/js/vendor/popper.min.js"></script>
<!-- Bootstrap Min Js -->
<script src="<?php echo base_url(); ?>assets/js/vendor/bootstrap.min.js"></script>
<!-- Plugins Js-->
<script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
<!-- Ajax Mail Js -->
<script src="<?php echo base_url(); ?>assets/js/ajax-mail.js"></script>
<!-- Active Js -->
<script src="<?php echo base_url(); ?>assets/js/main.js"></script>
<script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
<!-- Switcher JS [Please Remove this when Choose your Final Projct] -->
<script src="<?php echo base_url(); ?>assets/js/switcher.js"></script>
</body>
</html>