$('#regi_form').on('submit',function(e){
	e.preventDefault();

	//$('#regi_form').submit();
	var elements = ['fullname','email','password','cpassword'];

	var formData = new FormData(this);

	$.ajax({
		type:'POST',
		url:basepath+'loginregister/registeruser',
		data:formData,
		cache: false,
        contentType: false,
        processData: false,
		success:function (res) {
			var result = JSON.parse(res);
			if(result.status==0){
				for (var i = 0; i < elements.length; i++) {
					$('.'+elements[i]+'-error').text(result.message[elements[i]]);
					$('.'+elements[i]+'-error').removeClass('hide');
					$('.'+elements[i]+'-error').addClass('show');
				}
			}
			if(result.status==1){
				for (var i = 0; i < elements.length; i++) {
					$('.'+elements[i]+'-error').text('');
					$('.'+elements[i]+'-error').removeClass('show');
					$('.'+elements[i]+'-error').addClass('hide');
				}
				$('#success_msg').text(result.message);
				setTimeout(function(){
					$('#success_msg').text('');
					$('#regi_form')[0].reset();
				},1000);
			}
			
		}
	})
});

$('#login_form').on('submit',function(e){
	e.preventDefault();

	//$('#regi_form').submit();
	var elements = ['loginemail','loginpassword'];

	var formData = new FormData(this);

	$.ajax({
		type:'POST',
		url:basepath+'loginregister/loginuser',
		data:formData,
		cache: false,
        contentType: false,
        processData: false,
		success:function (res) {
			var result = JSON.parse(res);
			if(result.status==0){
				for (var i = 0; i < elements.length; i++) {
					$('.'+elements[i]+'-error').text(result.message[elements[i]]);
					$('.'+elements[i]+'-error').removeClass('hide');
					$('.'+elements[i]+'-error').addClass('show');
				}
			}
			if(result.status==2){
				$('#login_success_msg').text(result.message);
				setTimeout(function(){
					$('#login_success_msg').text('');
				},1000);
			}
			if(result.status==1){
				for (var i = 0; i < elements.length; i++) {
					$('.'+elements[i]+'-error').text('');
					$('.'+elements[i]+'-error').removeClass('show');
					$('.'+elements[i]+'-error').addClass('hide');
				}
				$('#login_success_msg').text(result.message);
				setTimeout(function(){
					$('#login_success_msg').text('');
					$('#login_form')[0].reset();

					var lastsegment = window.location.href.split('/');

					if(lastsegment[lastsegment.length-1] == 'checkout'){
						window.location = basepath+'productdetails/checkout';
					} else {
						window.location = basepath+'dashboard';
					}
				},1000);
			}
			
		}
	})
});

$('#add_to_cart').click(function(){

	var url = new URL(window.location.href);
	var c = url.searchParams.get("p_id");

	$.ajax({
		type:'POST',
		url:basepath+'productdetails/addtocart',
		data:{'p_id':c},
		success:function (res) {
			console.log(res);
		}
	})
});

$('#place_order').click(function(){

	var elements = ['billing_fname','billing_lname','billing_email','billing_country','billing_address_line1','billing_city','billing_postcode','shipping_fname','shipping_lname','shipping_email','shipping_country','shipping_address_line1','shipping_city','shipping_postcode','account_password'];

	$.ajax({
		type:'POST',
		url:basepath+'productdetails/place_order',
		data:$('#checkout_form').serialize(),
		//cache: false,
        //contentType: false,
        //processData: false,
		success:function (res) {
			var result = JSON.parse(res);
			if(result.status==0){
				for (var i = 0; i < elements.length; i++) {

					if(i<=6){
						//for billing form

						$('.'+elements[i]+'-error').text(result.message[elements[i]]);
						$('.'+elements[i]+'-error').removeClass('hide');
						$('.'+elements[i]+'-error').addClass('show');
					} else {
						//for shipping form 

						if ($('#ship_to_different').prop("checked")) {
					        // checked
					        $('.'+elements[i]+'-error').text(result.message[elements[i]]);
							$('.'+elements[i]+'-error').removeClass('hide');
							$('.'+elements[i]+'-error').addClass('show');
					    } else if($('#create_pwd').prop("checked")){
					    	console.log('here');
					    	$('.account_password-error').text(result.message[elements[i]]);
							$('.account_password-error').removeClass('hide');
							$('.account_password-error').addClass('show');
					    }
					}
					
				}
			}
			if(result.status==2){
				$('#order_success_msg').text(result.message);
				setTimeout(function(){
					$('#order_success_msg').text('');
					window.location = basepath+'dashboard';
				},1000);
			}
			if(result.status==3){
				$('#order_success_msg').text(result.message);
				$('#order_success_msg').css('color','red');
				setTimeout(function(){
					$('#order_success_msg').text('');
					$('#checkout_form').reset();
				},1000);
			}
			if(result.status==1){
				for (var i = 0; i < elements.length; i++) {
					$('.'+elements[i]+'-error').text('');
					$('.'+elements[i]+'-error').removeClass('show');
					$('.'+elements[i]+'-error').addClass('hide');
				}
				$('#order_success_msg').text(result.message);
				setTimeout(function(){
					$('#order_success_msg').text('');
					$('#checkout_form')[0].reset();

					var lastsegment = window.location.href.split('/');

					if(lastsegment[lastsegment.length-1] == 'checkout'){
						window.location = basepath+'productdetails/checkout';
					} else {
						window.location = basepath+'dashboard';
					}
				},1000);
			}
			
		}
	})
});