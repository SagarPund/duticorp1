<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductDetails extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->validation_msg = array();
		$this->load->model('Checkout_model');
		$this->load->model('LoginRegister_model');
	}

	public function index()
	{
		$this->load->view('header/header');
		$this->load->view('productdetails/middle');
		$this->load->view('footer/footer');
	}

	public function checkout()
	{
		// if($this->session->userdata('user_id') == '') { 
        //     redirect('/loginregister');
        // }
		$this->load->view('header/header');
		$this->load->view('productdetails/checkout');
		$this->load->view('footer/footer');
	}

	public function addtocart(){

		if(isset($_COOKIE['my_cart']) && $_COOKIE['my_cart']!=''){
			$previous_cart = explode(',',$this->input->cookie('my_cart'));
			//print_r($previous_cart);exit;
			if(!in_array($_REQUEST['p_id'],$previous_cart)){

				array_push($previous_cart,$_REQUEST['p_id']);

				$cookie = array(
                        'name'   => 'my_cart',
                        'value'  => implode(',',$previous_cart),                            
                        'expire' => '3600',                                                                                   
                        'secure' => TRUE
                        );
				$this->input->set_cookie($cookie);
			}
		} else {
			$cookie = array(
                        'name'   => 'my_cart',
                        'value'  => $_REQUEST['p_id'],                            
                        'expire' => '3600',                                                                                   
                        'secure' => TRUE
                        );
			$this->input->set_cookie($cookie);
			echo "1";
		}

	}

	public function validate_name($str) {

		if($str==''){
			$this->form_validation->set_message("validate_name", '%s is required.');
            return false;
		} else if (preg_match("/^([-a-z_ ])+$/i", $str) !== 0) {
            return true;
        } else {
            $this->form_validation->set_message("validate_name", '%s is not valid.');
            return false;
        }
	}
	public function prepare_validation_arr(){
		$res = '';
		if ($this->form_validation->run() == FALSE)
	    {
	    	$res = explode('*',validation_errors());
	    	//echo "<pre>";print_r($this->validation_msg);
	    	if(!in_array($res[count($res)-2], $this->validation_msg)){
	    		
	    		array_push($this->validation_msg,$res[count($res)-2]);
	    		$res = $res[count($res)-2];
	    	} else {
	    		$res = '';
	    	}
		}
		return $res;

	}

	public function place_order(){

		//echo "<pre>";print_r($_POST);exit;

		$this->form_validation->set_error_delimiters('', '*');

	    $this->form_validation->set_rules('billing_fname', 'Billing first name', 'trim|required|callback_validate_name');
	    $data['message']['billing_fname'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_lname', 'Billing last name', 'trim|required|callback_validate_name');
	    $data['message']['billing_lname'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_email', 'Billing Email', 'trim|required|valid_email');
	    $data['message']['billing_email'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_country', 'Billing country', 'required');
	    $data['message']['billing_country'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_address_line1', 'Billing address', 'required');
	    $data['message']['billing_address_line1'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_city', 'Billing city', 'required');
	    $data['message']['billing_city'] = $this->prepare_validation_arr();

	    $this->form_validation->set_rules('billing_postcode', 'Billing postcode', 'required');
	    $data['message']['billing_postcode'] = $this->prepare_validation_arr();

	    if(isset($_POST['create_pwd']) && $_POST['create_pwd']!='' && $_POST['create_pwd']=='on') {
	    	$this->form_validation->set_rules('account_password', 'Account password', 'required');
	    	$data['message']['account_password'] = $this->prepare_validation_arr();
	    }

	    if(isset($_POST['ship_to_different']) && $_POST['ship_to_different']!='' && $_POST['ship_to_different']=='on') {
	    	//echo "here";exit;
	    	$this->form_validation->set_rules('shipping_fname', 'Shipping first name', 'trim|required|callback_validate_name');
		    $data['message']['shipping_fname'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_lname', 'Shipping last name', 'trim|required|callback_validate_name');
		    $data['message']['shipping_lname'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_email', 'Shipping Email', 'trim|required|valid_email');
		    $data['message']['shipping_email'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_country', 'Shipping country', 'required');
		    $data['message']['shipping_country'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_address_line1', 'Shipping address', 'required');
		    $data['message']['shipping_address_line1'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_city', 'Shipping city', 'required');
		    $data['message']['shipping_city'] = $this->prepare_validation_arr();

		    $this->form_validation->set_rules('shipping_postcode', 'Shipping postcode', 'required');
		    $data['message']['shipping_postcode'] = $this->prepare_validation_arr();
	    }

	    if ($this->form_validation->run() == FALSE) {
	    	
	        $data['status'] = 0;
	    } else {

	    	if(isset($_POST['create_pwd']) && $_POST['create_pwd']!='' && $_POST['create_pwd']=='on') {
		    	$users = array(
		            'fullname'      => $_POST['billing_fname'].' '.$_POST['billing_lname'],
		            'email'         => $_POST['billing_email'],
		            'password'      => $_POST['account_password'],
		            'status'        => 'active'
		        );

		        $user_res = $this->LoginRegister_model->insert($users);
		        if($user_res==1){
		       		$data['status'] = 0;
		       		$data['message']['billing_email'] = 'Dublicate email id.';
		       		unset($this->validation_msg);
	    			echo json_encode($data);exit;
		       	}
		       	
		    }

	    	$address_ids = array();
	    	$billing_address = array(

	    		'user_id'		=>	($_SESSION['user_id'])? $_SESSION['user_id'] : '',
				'fname'			=> $_POST['billing_fname'],
				'lname'			=> $_POST['billing_lname'],
				'email'			=> $_POST['billing_email'],
				'company_name'	=> $_POST['billing_company_name'],
				'address'		=> $_POST['billing_address_line1'].' '.$_POST['billing_address_line2'],	
				'country'		=> $_POST['billing_country'],
				'state'			=> $_POST['billing_state'],
				'city'			=> $_POST['billing_city'],
				'postcode'		=> $_POST['billing_postcode'],
				'phone'			=> $_POST['billing_phone'],
				'address_type'	=> 'billing',
				'status'		=> 'active',
				'created_at'	=> date('Y-m-d h:i:s')

	    	);

	    	$billing_address_res = $this->Checkout_model->insert('user_billing_shipping_details',$billing_address);

	    	array_push($address_ids,$billing_address_res);

	    	if(isset($_POST['ship_to_different']) && $_POST['ship_to_different']!='' && $_POST['ship_to_different']=='on') {

	    		$shipping_address = array(

		    		'user_id'		=> ($_SESSION['user_id'])? $_SESSION['user_id'] : '',
					'fname'			=> $_POST['shipping_fname'],
					'lname'			=> $_POST['shipping_lname'],
					'email'			=> $_POST['shipping_email'],
					'company_name'	=> $_POST['shipping_company_name'],
					'address'		=> $_POST['shipping_address_line1'].' '.$_POST['shipping_address_line2'],	
					'country'		=> $_POST['shipping_country'],
					'state'			=> $_POST['shipping_state'],
					'city'			=> $_POST['shipping_city'],
					'postcode'		=> $_POST['shipping_postcode'],
					'address_type'	=> 'shipping',
					'status'		=> 'active',
					'created_at'	=> date('Y-m-d h:i:s')

		    	);

		    	$shipping_address_res = $this->Checkout_model->insert('user_billing_shipping_details',$shipping_address);

		    	array_push($address_ids,$shipping_address_res);

	    	}

		    $order_details = array(

		    	'user_id'					=> ($_SESSION['user_id'])? $_SESSION['user_id'] : '',
				'billing_shipping_addr_id' 	=> implode(',',$address_ids),
				'product_id' 				=> $_COOKIE['my_cart'],
				'order_note' 				=> $_POST['ordernote'],
				'payment_type'				=> 'COD',
				'total_amount'				=> $_POST['total_amount'],
				'status' 					=> 'Pending',
				'created_at' 				=>	date('Y-m-d h:i:s')

		    );

		    $order_id = $this->Checkout_model->insert('user_order_details',$order_details);
		    if($order_id){
		    	unset($data);
		    	$data['status'] = 2;
		    	$data['message'] = 'Order placed successfully!.';

		    } else {
		    	unset($data);
		    	$data['status'] = 2;
		    	$data['message'] = 'Something went wrong!.';
		    }
	    }

	    unset($this->validation_msg);
	    echo json_encode($data);

	}
}
