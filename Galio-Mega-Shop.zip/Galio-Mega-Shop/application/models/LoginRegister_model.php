<?php
class LoginRegister_model extends CI_Model {

    public function check_validation($table_name,$column_name,$column_value,$alldata = '',$input = '',$edit_id = '',$rowno = '',$rowperpage = ''){
        $this->db->select('*');
        $this->db->from($table_name);
        if($alldata==''){
            if(isset($edit_id) && $edit_id!=''){
                $this->db->where('id!=',$edit_id);
                $this->db->where($column_name,$column_value);
            } else {
                $this->db->where($column_name,$column_value);
            }
        }
        //print_r($input);exit;
        if(isset($input['id']) && $input['id']!=''){
            $this->db->where('id',$input['id']);
        }
        $this->db->where('status','active');
        if($alldata=='get' && empty($input)){
            $this->db->order_by('id','desc');
        }
        if($rowno!=''){
            $this->db->limit($rowperpage, $rowno);
        }
        $data = $this->db->get()->result_array();
        //echo $this->db->last_query();exit();
        if($alldata==''){
            return count($data);
        }else {
            return $data;
        }
    }
    public function insert($data){
        $insert_arr = array(
            'fullname'      => $data['fullname'],
            'email'         => $data['email'],
            'password'      => $data['password'],
            'status'        => 'active'
        );

        if(isset($data['user_id'])){
            $insert_arr['updated_on'] = date('Y-m-d h:i:s');
        } else {
            $insert_arr['created_on'] = date('Y-m-d h:i:s');
        }

        if($this->check_validation('users','email',$data['email'],'','','') > 0){
            return '1';
        }

        return ($this->db->insert('users',$insert_arr)) ? 'Record Inserted Successfully' : 'Something went wrong.';

        
    }

    public function loginchk($email,$password){

        $this->db->select('*');
        $this->db->from('users');
        if($password==''){
            $this->db->where('email',$email);
        }
        if($password!=''){
            $this->db->where('email',$email);
            $this->db->where('password',$password);
        }
        $this->db->where('status','active');
        return $this->db->get()->result_array();
    }
}
?>