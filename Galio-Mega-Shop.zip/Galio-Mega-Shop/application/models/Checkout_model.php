<?php
class Checkout_model extends CI_Model {

	public function insert($table_name,$data){
        
        return ($this->db->insert($table_name,$data)) ? $this->db->insert_id() : '0';

        
    }

}

?>