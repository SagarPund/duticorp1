<!-- color switcher start -->
<div class="color-switcher">
<div class="color-switcher-inner">
    <div class="switcher-icon">
        <i class="fa fa-cog fa-spin"></i>
    </div>

    <div class="switcher-panel-item">
        <h3>Color Schemes</h3>
        <ul class="nav flex-wrap colors">
            <li class="default active" data-color="default" data-toggle="tooltip" data-placement="top" title="Red"></li>
            <li class="green" data-color="green" data-toggle="tooltip" data-placement="top" title="Green"></li>
            <li class="soft-green" data-color="soft-green" data-toggle="tooltip" data-placement="top" title="Soft-Green"></li>
            <li class="sky-blue" data-color="sky-blue" data-toggle="tooltip" data-placement="top" title="Sky-Blue"></li>
            <li class="orange" data-color="orange" data-toggle="tooltip" data-placement="top" title="Orange"></li>
            <li class="violet" data-color="violet" data-toggle="tooltip" data-placement="top" title="Violet"></li>
        </ul>
    </div>

    <div class="switcher-panel-item">
        <h3>Layout Style</h3>
        <ul class="nav layout-changer">
            <li><button class="btn-layout-changer active" data-layout="wide">Wide</button></li>
            <li><button class="btn-layout-changer" data-layout="boxed">Boxed</button></li>
        </ul>
    </div>

    <div class="switcher-panel-item bg">
        <h3>Background Pattern</h3>
        <ul class="nav flex-wrap bgbody-style bg-pattern">
            <li><img src="assets/img/bg-panel/bg-pettern/1.png" alt="Pettern"></li>
            <li><img src="assets/img/bg-panel/bg-pettern/2.png" alt="Pettern"></li>
            <li><img src="assets/img/bg-panel/bg-pettern/3.png" alt="Pettern"></li>
            <li><img src="assets/img/bg-panel/bg-pettern/4.png" alt="Pettern"></li>
            <li><img src="assets/img/bg-panel/bg-pettern/5.png" alt="Pettern"></li>
            <li><img src="assets/img/bg-panel/bg-pettern/6.png" alt="Pettern"></li>
        </ul>
    </div>

    <div class="switcher-panel-item bg">
        <h3>Background Image</h3>
        <ul class="nav flex-wrap bgbody-style bg-img">
            <li><img src="assets/img/bg-panel/bg-img/01.jpg" alt="Images"></li>
            <li><img src="assets/img/bg-panel/bg-img/02.jpg" alt="Images"></li>
            <li><img src="assets/img/bg-panel/bg-img/03.jpg" alt="Images"></li>
            <li><img src="assets/img/bg-panel/bg-img/04.jpg" alt="Images"></li>
            <li><img src="assets/img/bg-panel/bg-img/05.jpg" alt="Images"></li>
            <li><img src="assets/img/bg-panel/bg-img/06.jpg" alt="Images"></li>
        </ul>
    </div>
</div>
</div>
<!-- color switcher end -->

<div class="wrapper box-layout">

<?php $this->view('header/head-common.php'); ?>

<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">login-register</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- login register wrapper start -->
<div class="login-register-wrapper">
    <div class="container">
        <div class="member-area-from-wrap">
            <div class="row">
                <!-- Login Content Start -->
                <div class="col-lg-6">
                    <div class="login-reg-form-wrap  pr-lg-50">
                        <h2>Sign In</h2>
                        <form method="post" id="login_form">
                            <div class="single-input-item">
                                <input type="text" name="loginemail" placeholder="Email or Username"/>
                                <span class="loginemail-error hide validation-error"> Please enter email  </span>
                            </div>
                            <div class="single-input-item">
                                <input type="password" name="loginpassword" placeholder="Enter your Password"/>
                                <span class="loginpassword-error hide validation-error"> Please enter password  </span>
                            </div>
                            <div class="single-input-item">
                                <div class="login-reg-form-meta d-flex align-items-center justify-content-between">
                                    <div class="remember-meta">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="rememberMe">
                                            <label class="custom-control-label" for="rememberMe">Remember Me</label>
                                        </div>
                                    </div>
                                    <a href="#" class="forget-pwd">Forget Password?</a>
                                </div>
                            </div>
                            <span style="color:green;" id="login_success_msg"></span>
                            <div class="single-input-item">
                                <button class="sqr-btn" id="login_submit_btn">Login</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Login Content End -->

                <!-- Register Content Start -->
                <div class="col-lg-6">
                    <div class="login-reg-form-wrap mt-md-34 mt-sm-34">
                        <h2>Singup Form</h2>
                        <form method="post" id="regi_form">
                            <div class="single-input-item">
                                <input type="text" name="fullname" placeholder="Full Name"/>
                                <span class="fullname-error hide validation-error"> Please enter fullname  </span>
                            </div>
                            <div class="single-input-item">
                                <input type="text" name="email" placeholder="Enter your Email"/>
                                <span class="email-error hide validation-error"> Please enter fullname  </span>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="single-input-item">
                                        <input type="password" name="password" placeholder="Enter your Password" />
                                        <span class="password-error hide validation-error"> Please enter fullname  </span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="single-input-item">
                                        <input type="password" name="cpassword" placeholder="Repeat your Password" />
                                        <span class="cpassword-error hide validation-error"> Please enter fullname  </span>
                                    </div>
                                </div>
                            </div>
                            <div class="single-input-item">
                                <div class="login-reg-form-meta">
                                    <div class="remember-meta">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input" id="subnewsletter">
                                            <label class="custom-control-label" for="subnewsletter">Subscribe Our Newsletter</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <span style="color:green;" id="success_msg"></span>
                            <div class="single-input-item">
                                <button class="sqr-btn" id="submit_btn">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- Register Content End -->
            </div>
        </div>
    </div>
</div>
<!-- login register wrapper end -->

<!-- brand area start -->
<div class="brand-area pt-34 pb-30">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title mb-30">
                    <div class="title-icon">
                        <i class="fa fa-crop"></i>
                    </div>
                    <h3>Popular Brand</h3>
                </div> <!-- section title end -->
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="brand-active slick-padding slick-arrow-style">
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br1.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br2.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br3.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br4.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br5.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br6.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="assets/img/brand/br4.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- brand area end -->